import SwiftUI
struct OneView: View {
    var body: some View {
        Text("1234567890122987654189397541417829200272635353683939")
    }
}
